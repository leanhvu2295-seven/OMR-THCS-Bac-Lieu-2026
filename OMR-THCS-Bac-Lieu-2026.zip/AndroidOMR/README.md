# OMR – TRƯỜNG THCS BẠC LIÊU - NINH BÌNH (Android source)

## Mở và tạo APK
1. Cài Android Studio bản ổn định, Android SDK Platform 35 và JDK 17.
2. Mở thư mục `AndroidOMR` bằng Android Studio.
3. Chờ Gradle Sync hoàn tất; chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug được tạo tại `app/build/outputs/apk/debug/app-debug.apk`.

## Tính năng trong bản beta
- Ứng dụng Android dạng WebView, giao diện tiếng Việt, tên trường đã đặt sẵn.
- Chọn hai chế độ: mẫu Bộ GD&ĐT 2026 và mẫu riêng của trường.
- Chụp/chọn ảnh phiếu từ thiết bị; nhập/sửa đáp án, chấm, lưu cục bộ, xem bảng điểm, xuất CSV, in kết quả qua dịch vụ in Android.
- Chế độ mẫu trường kế thừa bộ OMR thử nghiệm 36 câu A–D từ bản web trước.

## Giới hạn cần biết trước khi dùng
- Đây là **mã nguồn Android beta**, chưa phải APK đã biên dịch hoặc kiểm thử trên thiết bị. Môi trường đóng gói hiện tại không có Android SDK/Gradle nên không thể xác nhận APK cài đặt được.
- Chế độ mẫu Bộ 2026 hiện mới là lựa chọn chế độ và quy trình nhập/đối chiếu; bộ đọc ảnh chưa được hiệu chuẩn tọa độ theo phiếu gốc của Bộ. Không dùng chức năng đọc tự động cũ để chấm phiếu Bộ. Cần bổ sung thuật toán riêng cho từng vùng đáp án của mẫu Bộ, kiểm thử ảnh quét thực tế và đối sánh trước khi bật tự động chấm.
- Bộ OMR mẫu trường vẫn sử dụng tọa độ ước lượng từ mẫu phiếu cũ 36 câu A–D; bắt buộc giáo viên rà soát đáp án máy đọc. Chưa có OCR họ tên/lớp/SBD/mã đề.
- Dữ liệu hiện lưu trên thiết bị (localStorage), chưa đồng bộ nhiều máy, chưa có đăng nhập/phân quyền hoặc sao lưu máy chủ.
- OpenCV.js được tải từ Internet; cần kết nối mạng khi dùng tính năng căn chỉnh/đọc ảnh.

## Tham chiếu mẫu Bộ
Công văn 1257/BGDĐT-QLCL ngày 19/03/2026, Phụ lục VI quy định phiếu thành phẩm cao 295–297 mm, rộng 205–210 mm; giấy 100–120 g/m²; in hai màu và các điểm định vị chính xác. Văn bản nêu phiếu dùng trong kỳ thi phải in bằng kỹ thuật bảo đảm chất lượng, đồng đều, chính xác (ví dụ in offset), không dùng bản photocopy hoặc máy in màu. Vì vậy ứng dụng không tự nhận mẫu in thông thường là phiếu chính thức.

## Bài kiểm tra kết hợp trắc nghiệm + tự luận (bản cập nhật)
- Khi tạo đề, nhập tổng điểm và điểm tối đa dành cho tự luận. Điểm trắc nghiệm được tính trên phần điểm còn lại.
- Khi chấm phiếu, ứng dụng tính điểm trắc nghiệm từ đáp án đã xác nhận; giáo viên chấm bài viết và nhập điểm tự luận cùng nhận xét.
- Tổng điểm = điểm trắc nghiệm + điểm tự luận. Bảng kết quả và CSV có cột điểm từng phần và tổng điểm.
- Nút “In phiếu trả lời A4” tạo **hai tờ riêng**: phiếu trả lời trắc nghiệm và giấy làm bài tự luận. Đây là mẫu kiểm tra nội bộ tham chiếu cấu trúc Phụ lục VI và VII Công văn 1257/BGDĐT-QLCL năm 2026, không phải bản sao phiếu chính thức của Bộ.
- Chế độ Bộ vẫn khóa nhận diện tự động cho tới khi có phiếu gốc đúng mẫu để hiệu chuẩn tọa độ và kiểm thử. Không sử dụng phiếu nội bộ do ứng dụng in trong kỳ thi tốt nghiệp THPT chính thức.

### Kiểm thử cần thực hiện trước khi chấm thật
1. In mẫu nội bộ ở tỷ lệ 100% (không co giãn trang), thử tô bằng bút chì và chụp/scan nhiều điều kiện ánh sáng.
2. So sánh đáp án máy đọc với đáp án do giáo viên xác nhận; ghi nhận câu bỏ trống, tô nhạt, tẩy và tô nhiều lựa chọn.
3. Chạy ít nhất 20–30 phiếu thật trước khi cân nhắc bật đọc tự động cho một mẫu phiếu cụ thể.
4. Phần tự luận hiện là nhập điểm thủ công; ứng dụng không tự nhận dạng chữ viết hoặc tự chấm nội dung tự luận.
